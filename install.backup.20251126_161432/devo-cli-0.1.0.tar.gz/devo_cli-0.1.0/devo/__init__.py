"""
DEVO CLI - Multi-Agent AI Development System

Interactive command-line interface for the DEVO platform.
"""

__version__ = "0.1.0"
__author__ = "DEVO Team"
