"""
Utility functions for DEVO CLI.
"""
