# DEVO CLI

Interactive command-line interface for the DEVO Multi-Agent AI Development System.

## Installation

```bash
cd cli
pip install -r requirements.txt
pip install -e .
```

## Quick Start

### 1. Start the Backend

First, ensure the Django backend is running:

```bash
cd ../backend
python manage.py runserver
```

### 2. Login (Optional)

```bash
devo login
```

### 3. Create a Project

```bash
devo init my-project --description "My awesome project"
```

### 4. Start Chatting

```bash
devo chat
```

## Commands

### Project Management

- `devo init <name>` - Create a new project
- `devo projects` - List all projects
- `devo status` - Show project status
- `devo chat` - Start interactive chat session

### Agent Management

- `devo agents` - List agents in project

### Configuration

- `devo configure --list` - List all configuration
- `devo configure <key> <value>` - Set configuration value
- `devo login` - Login to DEVO
- `devo logout` - Logout from DEVO

### Information

- `devo version` - Show version
- `devo --help` - Show help

## Chat Commands

During a chat session, you can use these commands:

- `/status` - Show project status
- `/agents` - Show active agents
- `/help` - Show help
- `/exit` or `/quit` - Exit chat
- `Ctrl+C` - Pause and show options

## Configuration

Configuration is stored in `~/.devo/config.json`.

### Environment Variables

You can also configure DEVO using environment variables:

- `DEVO_API_URL` - Backend API URL (default: http://localhost:8000)
- `DEVO_API_KEY` - API authentication key
- `DEVO_PREFERRED_LLM` - Preferred LLM model (default: deepseek-r1:7b)
- `DEVO_VERBOSE` - Enable verbose output (default: false)

### Configuration File

Example `~/.devo/config.json`:

```json
{
  "api_url": "http://localhost:8000",
  "api_key": "your-api-key",
  "preferred_llm": "deepseek-r1:7b",
  "theme": "dark",
  "show_thinking": true,
  "show_tool_calls": true
}
```

## Features

### Rich Terminal UI

- Beautiful terminal interface with Rich library
- Syntax highlighting for code
- Progress indicators
- Markdown rendering

### Real-time Streaming

- WebSocket-based streaming of agent execution
- Live updates as agents work
- See thinking process (for reasoning models)

### Interrupt Handling

- Press `Ctrl+C` to pause execution
- Options to:
  - Pause and ask questions
  - Cancel current task
  - Save checkpoint and exit
  - Continue processing

### Context Awareness

- Maintains conversation history
- Agents have full project context
- Semantic code search
- Artifact registry

## Examples

### Create a new web application

```bash
$ devo init my-web-app --description "E-commerce platform"
$ devo chat

You: Create a REST API for products with CRUD operations

[Agent starts working...]
```

### Check project status

```bash
$ devo status

┌─────────────── Project Status ───────────────┐
│ Name: my-web-app                             │
│ Status: in_progress                          │
│ Files: 24 files | 1,234 LOC                  │
└──────────────────────────────────────────────┘

┌─────────────── Active Agents ────────────────┐
│ 🟢 Backend Lead    | working | Create API    │
│ ⚪ Frontend Lead   | idle    | -             │
└──────────────────────────────────────────────┘
```

### List agents

```bash
$ devo agents

┌─────────────────────────────────────────────┐
│              Active Agents                  │
├─────────────┬──────────┬─────────┬──────────┤
│ Agent       │ Type     │ Status  │ Task     │
├─────────────┼──────────┼─────────┼──────────┤
│ 🟢 Backend  │ backend  │ working │ API CRUD │
└─────────────┴──────────┴─────────┴──────────┘
```

## Development

### Running Tests

```bash
pytest
```

### Code Formatting

```bash
black .
ruff .
```

### Type Checking

```bash
mypy .
```

## Architecture

The CLI is structured as follows:

```
cli/
├── main.py              # Main Typer app and commands
├── config.py            # Configuration management
├── client/              # API and WebSocket clients
│   ├── api_client.py    # HTTP API client
│   └── ws_client.py     # WebSocket client
├── ui/                  # Rich UI components
│   ├── chat_panel.py    # Chat interface
│   └── status_panel.py  # Status display
├── commands/            # Command implementations
│   └── chat.py          # Chat session
└── utils/               # Utilities
```

## Troubleshooting

### Connection Errors

If you get connection errors:

1. Ensure backend is running: `cd ../backend && python manage.py runserver`
2. Check API URL: `devo configure api_url http://localhost:8000`
3. Verify health: `curl http://localhost:8000/api/health/`

### WebSocket Errors

If WebSocket streaming fails:

1. Ensure WebSocket support is enabled in backend
2. Check firewall settings
3. Try HTTP instead of HTTPS for local development

## License

[Your License]

## Support

For issues and questions:
- GitHub Issues: [your-repo]/issues
- Documentation: [your-docs-url]
