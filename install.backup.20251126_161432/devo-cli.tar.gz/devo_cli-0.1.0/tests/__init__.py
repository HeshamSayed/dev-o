"""
Tests for DEVO CLI.
"""
